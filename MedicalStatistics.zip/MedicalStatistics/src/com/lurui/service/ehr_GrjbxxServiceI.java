package com.lurui.service;

import com.lurui.pojo.ehr_Grjbxx;
import com.lurui.vo.ehr_GrjbxxVo;

import java.util.List;

public interface ehr_GrjbxxServiceI {
    List<ehr_GrjbxxVo> findList();
}
