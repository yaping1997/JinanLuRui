package com.lurui.service;

public interface ehr_JktjServiceI {
}
