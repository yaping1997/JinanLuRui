package com.lurui.service.Impl;

import com.lurui.mapper.ehr_GrjbxxMapper;
import com.lurui.mapper.ehr_JktjMapper;
import com.lurui.service.ehr_JktjServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ehr_JktjServiceImpl implements ehr_JktjServiceI {
    @Autowired
    private ehr_JktjMapper ehrJktjMapper;
}
