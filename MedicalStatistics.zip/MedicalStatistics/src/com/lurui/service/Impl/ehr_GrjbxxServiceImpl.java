package com.lurui.service.Impl;

import com.lurui.mapper.ehr_GrjbxxMapper;
import com.lurui.pojo.ehr_Grjbxx;
import com.lurui.service.ehr_GrjbxxServiceI;
import com.lurui.vo.ehr_GrjbxxVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ehr_GrjbxxServiceImpl implements ehr_GrjbxxServiceI {
    @Autowired
    private ehr_GrjbxxMapper ehrGrjbxxMapper;
    public List<ehr_GrjbxxVo> findList(){
        return this.ehrGrjbxxMapper.findList();
    }
}
