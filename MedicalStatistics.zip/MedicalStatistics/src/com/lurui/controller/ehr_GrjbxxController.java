package com.lurui.controller;

import com.lurui.pojo.ehr_Grjbxx;
import com.lurui.service.ehr_GrjbxxServiceI;
import com.lurui.vo.ehr_GrjbxxVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("grjbxx")
public class ehr_GrjbxxController {
    @Autowired
    private ehr_GrjbxxServiceI ehrGrjbxxServiceI;

    @RequestMapping("findList.action")
    public String findList(Model model){
        List<ehr_GrjbxxVo> ehrGrjbxxVoList = this.ehrGrjbxxServiceI.findList();
        model.addAttribute("ehrGrjbxxVoList",ehrGrjbxxVoList);
        return "data";
    }
}
