package com.lurui.mapper;

import com.lurui.pojo.ehr_Grjbxx;
import com.lurui.vo.ehr_GrjbxxVo;

import java.util.List;

public interface ehr_GrjbxxMapper {
    List<ehr_GrjbxxVo> findList();
}
