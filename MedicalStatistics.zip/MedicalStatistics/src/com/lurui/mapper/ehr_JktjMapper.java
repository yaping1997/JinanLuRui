package com.lurui.mapper;

public interface ehr_JktjMapper {
}
