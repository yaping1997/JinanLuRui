package com.lurui.vo;

import com.lurui.pojo.ehr_Grjbxx;

public class ehr_GrjbxxVo extends ehr_Grjbxx {
    private Integer GRID;
    private String Codebar; //条码号
    private String TijianDate;

    public Integer getGRID() {
        return GRID;
    }

    public void setGRID(Integer GRID) {
        this.GRID = GRID;
    }

    public String getCodebar() {
        return Codebar;
    }

    public void setCodebar(String codebar) {
        Codebar = codebar;
    }

    public String getTijianDate() {
        return TijianDate;
    }

    public void setTijianDate(String tijianDate) {
        TijianDate = tijianDate;
    }

}
