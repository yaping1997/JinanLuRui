package com.lurui.pojo;

import java.io.Serializable;

public class ehr_Jktj implements Serializable {
    private Integer GRID;
    private String Codebar; //条码号
    private String TijianDate; //查体日期

    public Integer getGRID() {
        return GRID;
    }

    public void setGRID(Integer GRID) {
        this.GRID = GRID;
    }

    public String getCodebar() {
        return Codebar;
    }

    public void setCodebar(String codebar) {
        Codebar = codebar;
    }

    public String getTijianDate() {
        return TijianDate;
    }

    public void setTijianDate(String tijianDate) {
        TijianDate = tijianDate;
    }

    public ehr_Jktj() {
    }

    public ehr_Jktj( Integer GRID, String codebar, String tijianDate) {
        this.GRID = GRID;
        Codebar = codebar;
        TijianDate = tijianDate;
    }
}
