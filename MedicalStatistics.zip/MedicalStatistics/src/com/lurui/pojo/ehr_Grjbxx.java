package com.lurui.pojo;

import java.io.Serializable;

public class ehr_Grjbxx implements Serializable {
   private Integer ID; //主键ID
   private String Name; //姓名
   private String Sex; //性别
   private String Cardnum; //身份证号
   private String Zhuzhi;//地址

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String sex) {
        Sex = sex;
    }

    public String getCardnum() {
        return Cardnum;
    }

    public void setCardnum(String cardnum) {
        Cardnum = cardnum;
    }

    public String getZhuzhi() {
        return Zhuzhi;
    }

    public void setZhuzhi(String zhuzhi) {
        Zhuzhi = zhuzhi;
    }

    public ehr_Grjbxx(Integer ID, String name, String sex, String cardnum, String zhuzhi) {
        this.ID = ID;
        Name = name;
        Sex = sex;
        Cardnum = cardnum;
        Zhuzhi = zhuzhi;
    }

    public ehr_Grjbxx() {
    }
}
