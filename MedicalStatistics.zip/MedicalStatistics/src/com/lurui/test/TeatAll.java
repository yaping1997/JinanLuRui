package com.lurui.test;

import com.lurui.mapper.ehr_GrjbxxMapper;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TeatAll {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        ehr_GrjbxxMapper tMapper = applicationContext.getBean(ehr_GrjbxxMapper.class);
        tMapper.findList().forEach(c-> System.out.println(c));
    }
}
